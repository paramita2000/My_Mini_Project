package com.management.student.studentresult.utils;

import java.util.Date;

public class CommonUtils {

    public static String formatDate(Date dob) {
        return "";
    }
}
